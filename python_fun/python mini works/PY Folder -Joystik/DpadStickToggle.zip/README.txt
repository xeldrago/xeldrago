DpadStickToggle - System-wide D-Pad -> Left Stick remapper (Toggle Mode)

Build:
dotnet restore
dotnet build -c Release

Run EXE:
bin/Release/net8.0/DpadStickToggle.exe
