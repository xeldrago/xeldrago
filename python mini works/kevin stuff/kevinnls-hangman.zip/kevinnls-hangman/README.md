# a CUI-based game of hangman created using Python
