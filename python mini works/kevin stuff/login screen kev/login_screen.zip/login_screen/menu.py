from clear import clear as clear
from clear import sleep as sleep

class menu:
    def __init__(self,uname):
        clear()
        print("Bananas Helpstaff Portal\n")
        sleep(1)
        print("Welcome to your account, " + uname + "!")
        exit()
