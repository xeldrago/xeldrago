using System;
using System.Linq;
using System.Threading;

namespace DpadStickToggle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("D-Pad -> Left Stick Remapper (Toggle Mode - L3 to toggle)
");
            var mapper = new DpadMapper();
            mapper.Run();
        }
    }
}
